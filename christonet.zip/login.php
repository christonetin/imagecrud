<?php session_start();?>
<!DOCTYPE html>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<html>
<style>
input[type=password],input[type=text], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

.card {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
  margin-top: 20px;
}
a{
	text-decoration:none;
	color:blue;
}
</style>
<body>
<div class="topnav" id="myTopnav">
 
  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
    <i class="fa fa-bars"></i>
  </a>
</div>


<div>
  <div class="container">
    <div class="row">
    <div class="col-12 mt-4">
    <h3>Admin Panel</h3>
      <div class="card">
      <form action="#" method="post">
    <label for="fname">User name</label>
    <input type="text" id="fname" name="u_id" class="form-control" placeholder="Your ID">

    <label for="lname">Password</label>
    <input type="password" id="lname" name="pass"  class="form-control" placeholder="Your Password">
    <input type="submit" name="login"  value="Submit">
  </form>
      </div>
    </div>
    </div>
  </div>


</div>

</body>
</html>
