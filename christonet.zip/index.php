<?php include "include/header.php" ?>

<div class="wrapper">

    <?php include "include/navbar.php" ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                Dashboard
                <small>Control panel</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
                <li class="active">Dashboard</li>
            </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <!-- Small boxes (Stat box) -->
            <div class="row">
          <!--  <form action="action.php" method="post">
								<input type="number" name="cnt" id="" class="form-control" required>
								<button class="btn btn-info" name="dublicate_id_create">Submit</button>
							</form>---->
            
                
                <!-- ./col -->
            	<style>
                        .small-box .icon i{
                            font-size: 40px;
                        }
                    </style>
                <div class="col-lg-3 col-xs-6">
                    <!-- small box -->
				
					<a href="#" style="text-decoration:none">
                    <div class="small-box bg-green">
                        <div class="inner">
                          
                          <h3>1</h3>
                            <p>Total Images</p>
							
                        </div>
						
                        <div class="icon">
                        <i class="fa fa-pie-chart" aria-hidden="true"></i>
                        </div>
                       
                    </div>
					</a>
                </div>
               
              
             
                    </div>
                 
              
		


        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

    <?php include "include/footer.php" ?>
